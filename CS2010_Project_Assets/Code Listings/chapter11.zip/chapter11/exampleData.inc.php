<?php
$name = 'Randy Connolly';
$email = 'someone@example.com';
?>