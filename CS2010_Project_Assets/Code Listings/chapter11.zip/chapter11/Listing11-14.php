<?php

/**
* This function outputs the footer menu
*/
function outputFooterMenu() {
    echo '<div id="footer">';
    echo '<a href=#>Home</a> | <a href=#>Products</a> | ';
    echo '<a href=#>About us</a> | <a href=#>Contact us</a>';
    echo '</div>';
}

//demo the function
outputFooterMenu();

?>