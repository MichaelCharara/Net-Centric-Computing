<?php
function mustReturnString() : string {
    return "hello";
}

echo mustReturnString();
?>