<?php
# single-line comment
/*
This is a multiline comment.
They are a good way to document functions or complicated blocks of code
*/
$artist = readDatabase(); // end-of-line comment
?>