<?php

$count = 0;
while ($count < 10)
{
    echo $count;
    $count++;
}
$count = 0;
do
{
    echo $count;
    $count++;
} while ($count < 10);

?>