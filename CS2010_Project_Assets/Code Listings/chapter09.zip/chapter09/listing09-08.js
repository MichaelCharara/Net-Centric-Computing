function submitButtonClicked(e) {
   // prevent the submit action
   e.preventDefault();
   // now do other amazing things
   // ...
}