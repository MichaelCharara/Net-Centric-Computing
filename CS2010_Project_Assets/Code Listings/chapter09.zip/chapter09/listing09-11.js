window.addEventListener("load", function() {
   // the DOM can be safely manipulated within this function
   // ...
});