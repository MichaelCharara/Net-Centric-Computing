var myButton = document.getElementById('example');
myButton.onclick = alert('some message');