// defines a function using an anonymous function expression
var calculateSubtotal = function (price,quantity) {
   return price * quantity;
};
// invokes the function
var result = calculateSubtotal(10,2);