var hourOfDay; // var to hold hour of day, set it later ...
var greeting; // var to hold the greeting message
if (hourOfDay > 4 && hourOfDay < 12) {
   greeting = "Good Morning";
}
else if (hourOfDay >= 12 && hourOfDay < 18) {
   greeting = "Good Afternoon";
}
else {
g  reeting = "Good Evening";
}