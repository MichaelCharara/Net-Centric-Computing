var order = {
   salesDate : "May 5, 2016",
   product: {
      type: "laptop",
      price: 500.00,
      brand: "Acer"
   },
   customer: {
      name: "Sue Smith",
      address: "123 Somewhere St",
      city: "Calgary"
   }
};
alert(order.salesDate);
alert(order.product.type);
alert(order.customer.name);